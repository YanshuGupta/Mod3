$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/resources/MYfeature.feature");
formatter.feature({
  "name": "HotelBooking",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "check the tittle",
  "description": "",
  "keyword": "Scenario"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "User is on login page",
  "keyword": "Given "
});
formatter.match({
  "location": "stepdefs.user_is_on_login_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "check the tittle of login page",
  "keyword": "Then "
});
formatter.match({
  "location": "stepdefs.check_the_tittle_of_login_page()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.scenario({
  "name": "Successfully user login with all valid data",
  "description": "",
  "keyword": "Scenario"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "User is on login page",
  "keyword": "Given "
});
formatter.match({
  "location": "stepdefs.user_is_on_login_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user enter the valid data",
  "keyword": "When "
});
formatter.match({
  "location": "stepdefs.user_enter_the_valid_data()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "navigate to hotelbooking page",
  "keyword": "Then "
});
formatter.match({
  "location": "stepdefs.navigate_to_hotelbooking_page()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.scenario({
  "name": "Failure of login on leaving the username empty",
  "description": "",
  "keyword": "Scenario"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "User is on login page",
  "keyword": "Given "
});
formatter.match({
  "location": "stepdefs.user_is_on_login_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User leave the username empty",
  "keyword": "When "
});
formatter.match({
  "location": "stepdefs.user_leave_the_username_empty()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click the login button",
  "keyword": "And "
});
formatter.match({
  "location": "stepdefs.click_the_login_button()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "display the alert msg",
  "keyword": "Then "
});
formatter.match({
  "location": "stepdefs.display_the_alert_msg()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.scenario({
  "name": "Failure of login on leaving the password empty",
  "description": "",
  "keyword": "Scenario"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "User is on login page",
  "keyword": "Given "
});
formatter.match({
  "location": "stepdefs.user_is_on_login_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User leave the password empty",
  "keyword": "When "
});
formatter.match({
  "location": "stepdefs.user_leave_the_password_empty()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click the login button",
  "keyword": "And "
});
formatter.match({
  "location": "stepdefs.click_the_login_button()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "display the alert box",
  "keyword": "Then "
});
formatter.match({
  "location": "stepdefs.display_the_alert_box()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.scenario({
  "name": "Failure in hotel login on incorrect userName",
  "description": "",
  "keyword": "Scenario"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "User is on hotel login page",
  "keyword": "Given "
});
formatter.match({
  "location": "stepdefs.user_is_on_hotel_login_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user enters incorrect userName",
  "keyword": "When "
});
formatter.match({
  "location": "stepdefs.user_enters_incorrect_userName()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "display Login alert msg",
  "keyword": "Then "
});
formatter.match({
  "location": "stepdefs.display_Login_alert_msg()"
});
formatter.result({
  "error_message": "org.openqa.selenium.NoAlertPresentException: no such alert\n  (Session info: chrome\u003d73.0.3683.86)\n  (Driver info: chromedriver\u003d2.41.578737 (49da6702b16031c40d63e5618de03a32ff6c197e),platform\u003dWindows NT 10.0.17763 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 8 milliseconds\nBuild info: version: \u00273.4.0\u0027, revision: \u0027unknown\u0027, time: \u0027unknown\u0027\nSystem info: host: \u0027DESKTOP-47UNP8N\u0027, ip: \u0027192.168.3.207\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_181\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities [{mobileEmulationEnabled\u003dfalse, hasTouchScreen\u003dfalse, platform\u003dXP, acceptSslCerts\u003dfalse, goog:chromeOptions\u003d{debuggerAddress\u003dlocalhost:54883}, acceptInsecureCerts\u003dfalse, webStorageEnabled\u003dtrue, browserName\u003dchrome, takesScreenshot\u003dtrue, javascriptEnabled\u003dtrue, setWindowRect\u003dtrue, unexpectedAlertBehaviour\u003d, applicationCacheEnabled\u003dfalse, rotatable\u003dfalse, networkConnectionEnabled\u003dfalse, chrome\u003d{chromedriverVersion\u003d2.41.578737 (49da6702b16031c40d63e5618de03a32ff6c197e), userDataDir\u003dC:\\Users\\YANSHU~1\\AppData\\Local\\Temp\\scoped_dir9104_27120}, takesHeapSnapshot\u003dtrue, pageLoadStrategy\u003dnormal, databaseEnabled\u003dfalse, handlesAlerts\u003dtrue, version\u003d73.0.3683.86, browserConnectionEnabled\u003dfalse, nativeEvents\u003dtrue, locationContextEnabled\u003dtrue, cssSelectorsEnabled\u003dtrue}]\nSession ID: 67b07d0a58d9d04074076beb881509dc\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:215)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:167)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:671)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:694)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver$RemoteTargetLocator.alert(RemoteWebDriver.java:1020)\r\n\tat stepdefs.display_Login_alert_msg(stepdefs.java:138)\r\n\tat ✽.display Login alert msg(src/test/resources/MYfeature.feature:26)\r\n",
  "status": "failed"
});
formatter.after({
  "status": "passed"
});
formatter.scenario({
  "name": "Failure in hotel login on incorrect password",
  "description": "",
  "keyword": "Scenario"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "User is on hotel login page",
  "keyword": "Given "
});
formatter.match({
  "location": "stepdefs.user_is_on_hotel_login_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user enters incorrect password",
  "keyword": "When "
});
formatter.match({
  "location": "stepdefs.user_enters_incorrect_password()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "display Login alert msg",
  "keyword": "Then "
});
formatter.match({
  "location": "stepdefs.display_Login_alert_msg()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.scenario({
  "name": "check the tittle",
  "description": "",
  "keyword": "Scenario"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "User is on hotelbooking page",
  "keyword": "Given "
});
formatter.match({
  "location": "stepdefs.user_is_on_hotelbooking_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "check the tittle of page",
  "keyword": "Then "
});
formatter.match({
  "location": "stepdefs.check_the_tittle_of_page()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.scenario({
  "name": "Successfully hotel booking with all data",
  "description": "",
  "keyword": "Scenario"
});
