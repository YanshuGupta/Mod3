import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Browser {
	 ChromeOptions chrome_options = new ChromeOptions();
	 WebDriver driver ;

	Browser(){
	String projectLocation=System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver",projectLocation + "\\lib\\chromedriver.exe");
		chrome_options.setExperimentalOption("useAutomationExtension", false);
		chrome_options.addArguments("--no-sandbox");
		chrome_options.addArguments("--disable-dev-shm-usage");
		driver = new ChromeDriver(chrome_options);
	}
	
	public  void goTo(String url) {
		driver.get(url);
	}

	public  String title() {
		return driver.getTitle();
	}

	public  void close() {
		driver.close();
	}
}
