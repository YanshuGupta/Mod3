   import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;




public class stepdefs {

private Login page;// =new Login();
private Hotelbooking book;
Browser browser;
@Before
public void testBefore() {
	browser=new Browser();
	page =new Login(browser);
	page.goTo(browser);
	book=new Hotelbooking(browser);
}


@Given("^User is on login page$")
public void user_is_on_login_page() throws Exception {
  
   // page.goTo();
	Assert.assertTrue(page.isAt(browser));
}

@Then("^check the tittle of login page$")
public void check_the_tittle_of_login_page() throws Exception {
	String title=browser.driver.getTitle();
	if(title.contentEquals("login")) System.out.println("****** Title Matched");
	else System.out.println("****** Title NOT Matched");
	browser.driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	
}

@When("^user enter the valid data$")
public void user_enter_the_valid_data() throws Exception {
	page.setPfuserName("capgemini");
	 Thread.sleep(3000);
	page.setPfuserPwd("capg1234");
	 Thread.sleep(3000);
	page.setPfbtn();
	 Thread.sleep(3000);
}

@Then("^navigate to hotelbooking page$")
public void navigate_to_hotelbooking_page() throws Exception {
	//Browser.driver.navigate().to("D:\\Practice\\SpringWebServices\\Bddpract\\src\\main\\webapp\\hotelbooking.html");
	// page.setPfbtn();
	 Thread.sleep(3000);
}

@When("^User leave the username empty$")
public void user_leave_the_username_empty() throws Exception {
	//Browser.
	//page.goTo();
//	System.out.println("Inside Username3 Empty");
//	page.setPfuserName("");
//	   Thread.sleep(3000);
//	
	page.setPfbtn();Thread.sleep(1000);

	assertEquals(page.getUserNameError(),"* Please enter userName.");
	
}


@When("^click the login button$")
public void click_the_login_button() throws Exception {
	Thread.sleep(3000);
	page.setPfbtn();
	Thread.sleep(3000);
	

  
}

@Then("^display the alert msg$")
public void display_the_alert_msg() throws Exception {
/*	  String alertMessage=Browser.driver.findElement(By.xpath(".//*[@id='userErrMsg']")).getText();
	    Thread.sleep(3000);
	    System.out.println("******" + alertMessage);*/
	Thread.sleep(3000);
	
}

@When("^User leave the password empty$")
public void user_leave_the_password_empty() throws Exception {
  page.setPfuserName("capgemini");
  page.setPfuserPwd("");
  Thread.sleep(3000);
	
}

@Then("^display the alert box$")
public void display_the_alert_box() throws Exception {
	 /* String alertMessage=Browser.driver.findElement(By.xpath(".//*[@id='userErrMsg']")).getText();
	    Thread.sleep(3000);
	    System.out.println("******" + alertMessage);*/
	page.setPfbtn();
	Thread.sleep(3000);
	
	
}

@Given("^User is on hotel login page$")
public void user_is_on_hotel_login_page() throws Exception {
	  
    page.goTo(browser);
	Assert.assertTrue(page.isAt(browser));
}

@When("^user enters incorrect userName$")
public void user_enters_incorrect_userName() throws Exception {
page.setPfuserName("capgeminii");
}

@Then("^display Login alert msg$")
public void display_Login_alert_msg() throws Exception {
			page.setPfbtn();
			Alert alert = page.browser.driver.switchTo().alert();
			String alertMsg = alert.getText();
			assertEquals(alertMsg, "Invalid login! Please try again!");
			Thread.sleep(500);
			alert.accept();
		

}

@When("^user enters incorrect password$")
public void user_enters_incorrect_password() throws Exception {
page.setPfuserName("capgemini");
page.setPfuserPwd("dddf");
}
@Given("^User is on hotelbooking page$")
public void user_is_on_hotelbooking_page() throws Exception {
/*browser.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	browser.driver.navigate().to("D:\\Practice\\SpringWebServices\\Bddpract\\src\\main\\webapp\\hotelbooking.html");
*/
	book.goTo(browser);}

@Then("^check the tittle of page$")
public void check_the_tittle_of_page() throws Exception {
	String title=browser.driver.getTitle();
	if(title.contentEquals("Hotel Booking")) System.out.println("****** Title Matched");
	else System.out.println("****** Title NOT Matched");
	browser.driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
}

@Given("^User is on booking page$")
public void user_is_on_booking_page() throws Exception {
  book.goTo(browser);
}

@When("^users enters all the valid data$")
public void users_enters_all_the_valid_data() throws Exception {
	book.setPffname("Mona");	Thread.sleep(1000);
	book.setPflname("soni");	Thread.sleep(1000);
	book.setPfemail("mona_soni@gmail.com");	Thread.sleep(1000);
	book.setPfmobile("8908445432");	Thread.sleep(1000);
	book.setPfcity("Pune");	Thread.sleep(1000);
	book.setPfstate("Karnataka");	Thread.sleep(1000);
	book.setPfpersons(4);	Thread.sleep(1000);
	book.setPfcardholder("Mona soni");	Thread.sleep(1000);
	book.setPfdebit("334567867897890");	Thread.sleep(1000);
	book.setPfcvv("999");	Thread.sleep(1000);
	book.setPfmonth("9");	Thread.sleep(1000);
	book.setPfyear("2020"); 
	browser.driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	book.setPfbutton();
	Thread.sleep(1000);
}

@Then("^navigate to welcome page$")
public void navigate_to_welcome_page() throws Exception {
browser.driver.navigate().to("D:\\Practice\\SpringWebServices\\Bddpract\\src\\main\\webapp\\success.html");
	browser.driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
}

@Given("^User is on hotel booking page$")
public void user_is_on_hotel_booking_page() throws Exception {
   book.goTo(browser); 
}

@When("^user leaves first Name blank$")
public void user_leaves_first_Name_blank() throws Exception {
	book.setPffname("");	 
	Thread.sleep(1000);
}

@When("^clicks the button$")
public void clicks_the_button() throws Exception {
book.setPfbutton();
}

@Then("^display alert msg$")
public void display_alert_msg() throws Exception {
	String alertMessage = browser.driver.switchTo().alert().getText();
	Thread.sleep(1000);
	browser.driver.switchTo().alert().accept();
    System.out.println("******" + alertMessage);
}

@When("^user leaves last Name blank and clicks the button$")
public void user_leaves_last_Name_blank_and_clicks_the_button() throws Exception {
    // Write code here that turns the phrase above into concrete actions
book.setPffname("mona");	
Thread.sleep(1000);
	book.setPflname("");	
	Thread.sleep(1000);
	book.setPfbutton();
}

@When("^user enters all data$")
public void user_enters_all_data() throws Exception {
book.setPffname("Mona");	Thread.sleep(1000);
	book.setPflname("soni");	Thread.sleep(1000);
	book.setPfemail("mona_soni@gmail.com");	Thread.sleep(1000);
	book.setPfmobile("8908445432");	Thread.sleep(1000);
	book.setPfcity("Pune");	Thread.sleep(1000);
	book.setPfstate("Karnataka");	Thread.sleep(1000);
	book.setPfpersons(4);	Thread.sleep(1000);
	book.setPfcardholder("Mona soni");	Thread.sleep(1000);
	book.setPfdebit("334567867897890");	Thread.sleep(1000);
	book.setPfcvv("078");	Thread.sleep(1000);
	book.setPfmonth("7");	Thread.sleep(1000);
	book.setPfyear("2020"); 
	browser.driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	book.setPfbutton();
	Thread.sleep(1000);
}

@When("^user enters incorrect email format and clicks the button$")
public void user_enters_incorrect_email_format_and_clicks_the_button() throws InterruptedException  {
	book.setPfemail("gsgfl@.com");
	Thread.sleep(1000);
book.setPfbutton();
}

@When("^user leaves MobileNo blank and clicks the button$")
public void user_leaves_MobileNo_blank_and_clicks_the_button() throws Exception {
	book.setPffname("mona");	
	Thread.sleep(1000);
	book.setPflname("soni");	
	Thread.sleep(1000);
	book.setPfemail("mona_soni@gmail.com");	
	Thread.sleep(1000);
	book.setPfmobile("");
	Thread.sleep(1000);
	book.setPfbutton();
}

@When("^user enters incorrect mobileNo format and clicks the button$")
public void user_enters_incorrect_mobileNo_format_and_clicks_the_button(DataTable arg1) throws Exception {
	book.setPffname("mona");	Thread.sleep(1000);
	book.setPflname("soni");	Thread.sleep(1000);
	book.setPfemail("mona_soni@gmail.com");	Thread.sleep(1000);
			
	List<String> objList = arg1.asList(String.class);
	//factory.setPfmobile(objList);	Thread.sleep(1000);
	book.setPfbutton();
	
	for(int i=0; i<objList.size(); i++) {
		if(Pattern.matches("^[7-9]{1}[0-9]{9}$", objList.get(i))) {
		System.out.println("***** Matched" + objList.get(i) + "*****");
		}
		else {
			System.out.println("***** NOT Matched" + objList.get(i) + "*****");
		}
	}}

@When("^user doesnot select city$")
public void user_doesnot_select_city() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	book.setPffname("mona");	Thread.sleep(1000);
	book.setPflname("soni");	Thread.sleep(1000);
	book.setPfemail("mona_soni@gmail.com");	Thread.sleep(1000);
	book.setPfmobile("8908765432");	Thread.sleep(1000);
	book.setPfcity("Select City");	Thread.sleep(1000);
	book.setPfbutton();
}

@When("^user doesnot select state$")
public void user_doesnot_select_state() throws Exception {
	book.setPffname("mona");	Thread.sleep(1000);
	book.setPflname("soni");	Thread.sleep(1000);
	book.setPfemail("mona_soni@gmail.com");	Thread.sleep(1000);
	book.setPfmobile("8908765432");	Thread.sleep(1000);
	book.setPfcity("Pune");	Thread.sleep(1000);
	book.setPfstate("Select State");	Thread.sleep(1000);
	book.setPfbutton();
}

@When("^user enters (\\d+)$")
public void user_enters(int arg1) throws Exception {
    // Write code here that turns the phrase above into concrete actions
	book.setPffname("mona");	Thread.sleep(1000);
	book.setPflname("soni");	Thread.sleep(1000);
	book.setPfemail("mona_soni@gmail.com");	Thread.sleep(1000);
	book.setPfmobile("8908765432");	Thread.sleep(1000);
	book.setPfcity("Pune");	Thread.sleep(1000);
	book.setPfstate("Karnataka");	Thread.sleep(1000);
	book.setPfpersons(arg1);	Thread.sleep(2000);
}

@Then("^allocate rooms such that (\\d+) room for minimum (\\d+) guests$")
public void allocate_rooms_such_that_room_for_minimum_guests(int arg1, int arg2) throws Exception {
    // Write code here that turns the phrase above into concrete actions
	if(arg2 <=3) {
    	System.out.println("***** 1 room");
    	assertEquals(1, arg1);
    }
    else if(arg2 <=6){
    	System.out.println("***** 2 rooms");
    	assertEquals(2, arg1); 	
    }	 
    else if(arg2 <=9){
    	System.out.println("***** 3 rooms");
    	assertEquals(3, arg1); 	
    }
	
}

@When("^user leaves CardHolderName blank and clicks the button$")
public void user_leaves_CardHolderName_blank_and_clicks_the_button() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	book.setPffname("mona");	Thread.sleep(1000);
	book.setPflname("soni");	Thread.sleep(1000);
	book.setPfemail("mona_soni@gmail.com");	Thread.sleep(1000);
	book.setPfmobile("8908765432");	Thread.sleep(1000);
	book.setPfcity("Pune");	Thread.sleep(1000);
	book.setPfstate("Karnataka");	Thread.sleep(1000);
	book.setPfpersons(7);	Thread.sleep(1000);
	book.setPfcardholder("");	Thread.sleep(1000);
	book.setPfbutton();
}

@When("^user leaves DebitCardNo blank and clicks the button$")
public void user_leaves_DebitCardNo_blank_and_clicks_the_button() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	book.setPffname("mona");	Thread.sleep(1000);
	book.setPflname("soni");	Thread.sleep(1000);
	book.setPfemail("mona_soni@gmail.com");	Thread.sleep(1000);
	book.setPfmobile("8908765432");	Thread.sleep(1000);
	book.setPfcity("Pune");	Thread.sleep(1000);
	book.setPfstate("Karnataka");	Thread.sleep(1000);
	book.setPfpersons(7);	Thread.sleep(1000);
	book.setPfcardholder("");	Thread.sleep(1000);
	book.setPfdebit("");	Thread.sleep(1000);
	book.setPfbutton();
}

@When("^user leaves expirationMonth blank and clicks the button$")
public void user_leaves_expirationMonth_blank_and_clicks_the_button() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	book.setPffname("mona");	Thread.sleep(1000);
	book.setPflname("soni");	Thread.sleep(1000);
	book.setPfemail("mona_soni@gmail.com");	Thread.sleep(1000);
	book.setPfmobile("8908765432");	Thread.sleep(1000);
	book.setPfcity("Pune");	Thread.sleep(1000);
	book.setPfstate("Karnataka");	Thread.sleep(1000);
	book.setPfpersons(7);	Thread.sleep(1000);
	book.setPfcardholder("");	Thread.sleep(1000);
	book.setPfdebit("5678567867897890");	Thread.sleep(1000);
	book.setPfcvv("078");	Thread.sleep(1000);
	book.setPfmonth("");	Thread.sleep(1000);
	book.setPfbutton();
}

@When("^user leaves expirationYr blank and clicks the button$")
public void user_leaves_expirationYr_blank_and_clicks_the_button() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	book.setPffname("mona");	Thread.sleep(1000);
	book.setPflname("soni");	Thread.sleep(1000);
	book.setPfemail("mona_soni@gmail.com");	Thread.sleep(1000);
	book.setPfmobile("8908765432");	Thread.sleep(1000);
	book.setPfcity("Pune");	Thread.sleep(1000);
	book.setPfstate("Karnataka");	Thread.sleep(1000);
	book.setPfpersons(7);	Thread.sleep(1000);
	book.setPfcardholder("");	Thread.sleep(1000);
	book.setPfdebit("5678567867897890");	Thread.sleep(1000);
	book.setPfcvv("078");	Thread.sleep(1000);
	book.setPfmonth("");	Thread.sleep(1000);
	book.setPfyear("");	Thread.sleep(1000);
	book.setPfbutton();
   

}
@After
public void close()
{
   browser.driver.close();	
}





}
